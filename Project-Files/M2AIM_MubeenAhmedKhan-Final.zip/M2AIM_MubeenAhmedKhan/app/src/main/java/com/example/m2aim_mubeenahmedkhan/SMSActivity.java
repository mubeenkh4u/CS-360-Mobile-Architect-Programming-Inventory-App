/*
 * -----------------------------------------------------------------------------------------
 * Course Name    :   CS 360 - Mobile Architect and Planning
 * Project Phase  :   Complete CRUD Implementation
 * App Type       :   Inventory Management
 * Professor Name :   Alex Benavente
 * Student Name   :   Mubeen Ahmed Khan (MAK)
 * Date           :   MAK  (as of completion 6/22/2025)
 * -----------------------------------------------------------------------------------------
 * Includes:
 * - Java source code for MainActivity, GridActivity, SMSActivity (for testing SMS Permissions
 * and for sending Toast Notifications)
 * - InventoryItemEntity model and InventoryAdapter for RecyclerView
 * - InventoryDao, UserDao, InventoryItemEntity to implement interfacing and with SQLite via ROOM
 * - UserEntity for inputting credentials into the app's database and for validating account
 * - XML Layouts: activity_main.xml, activity_grid.xml, item_inventory.xml, activity_sms.xml, dialog_edit_item.xml
 * - Resources: Strings.xml for better connecting the text based information
 * - Android Manifest: Updated to include launcher Icon to Launch application when built
 * -----------------------------------------------------------------------------------------
 * Note:
 *   This project was completed using Android Studio and followed the directions outlined in the Module Five Assignment Guidelines. Development and configuration were supported by the resources in the module, including:
 *   Android Developers – Build a Simple User Interface (developer.android.com)
 *   Android Developers – Design for Android (developer.android.com/design)
 *   zyBooks Chapter 5: Mobile Architecture & Programming – topics such as event handling, dynamic views, input validation and database usage.
 *
 * These resources helped guide the implementation of layout design, view behavior, input validation and database management for this assignment.
 */

package com.example.m2aim_mubeenahmedkhan;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {
    // Request code constant for SMS permission
    private static final int PERMISSION_REQUEST_SEND_SMS = 123;

    // UI components
    Button btnRequestPermission, btnSendSMS;
    TextView txtStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Bind views to XML layout
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnSendSMS = findViewById(R.id.btnSendSMS);
        txtStatus = findViewById(R.id.txtStatus);

        // Request SMS permission if not already granted
        btnRequestPermission.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(SMSActivity.this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // Ask for permission
                ActivityCompat.requestPermissions(SMSActivity.this,
                        new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
            } else {
                txtStatus.setText(getString(R.string.sms_already_granted));
            }
        });

        // Send SMS if permission is granted
        btnSendSMS.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                SmsManager smsManager = getSystemService(SmsManager.class);
                smsManager.sendTextMessage("+1234567890", null, "Low inventory alert!", null, null);
                Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Handle user response to permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                txtStatus.setText(getString(R.string.permission_granted));
            } else {
                txtStatus.setText(getString(R.string.permission_denied));
            }
        }
    }
}