/*
 * -----------------------------------------------------------------------------------------
 * Course Name    :   CS 360 - Mobile Architect and Planning
 * Project Phase  :   Complete CRUD Implementation
 * App Type       :   Inventory Management
 * Professor Name :   Alex Benavente
 * Student Name   :   Mubeen Ahmed Khan (MAK)
 * Date           :   MAK  (as of completion 6/22/2025)
 * -----------------------------------------------------------------------------------------
 * Includes:
 * - Java source code for MainActivity, GridActivity, SMSActivity (for testing SMS Permissions
 * and for sending Toast Notifications)
 * - InventoryItemEntity model and InventoryAdapter for RecyclerView
 * - InventoryDao, UserDao, InventoryItemEntity to implement interfacing and with SQLite via ROOM
 * - UserEntity for inputting credentials into the app's database and for validating account
 * - XML Layouts: activity_main.xml, activity_grid.xml, item_inventory.xml, activity_sms.xml, dialog_edit_item.xml
 * - Resources: Strings.xml for better connecting the text based information
 * - Android Manifest: Updated to include launcher Icon to Launch application when built
 * -----------------------------------------------------------------------------------------
 * Note:
 *   This project was completed using Android Studio and followed the directions outlined in the Module Five Assignment Guidelines. Development and configuration were supported by the resources in the module, including:
 *   Android Developers – Build a Simple User Interface (developer.android.com)
 *   Android Developers – Design for Android (developer.android.com/design)
 *   zyBooks Chapter 5: Mobile Architecture & Programming – topics such as event handling, dynamic views, input validation and database usage.
 *
 * These resources helped guide the implementation of layout design, view behavior, input validation and database management for this assignment.
 */

package com.example.m2aim_mubeenahmedkhan;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// Room database class that includes both inventory and user entities
@Database(entities = {InventoryItemEntity.class, UserEntity.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // Singleton instance
    private static AppDatabase INSTANCE;

    // DAO access methods
    public abstract InventoryDao inventoryDao();
    public abstract UserDao userDao();

    // Returns the singleton instance of the database
    public static synchronized AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "app_database"
                    )
                    .fallbackToDestructiveMigration() // Allows DB rebuild if schema changes
                    .allowMainThreadQueries()         // OK for Project Two (not recommended in production)
                    .build();
        }
        return INSTANCE;
    }
}