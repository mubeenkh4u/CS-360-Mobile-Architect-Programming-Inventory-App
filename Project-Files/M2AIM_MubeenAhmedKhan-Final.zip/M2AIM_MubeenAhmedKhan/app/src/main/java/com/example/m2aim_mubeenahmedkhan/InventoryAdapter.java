/*
 * -----------------------------------------------------------------------------------------
 * Course Name    :   CS 360 - Mobile Architect and Planning
 * Project Phase  :   Complete CRUD Implementation
 * App Type       :   Inventory Management
 * Professor Name :   Alex Benavente
 * Student Name   :   Mubeen Ahmed Khan (MAK)
 * Date           :   MAK  (as of completion 6/22/2025)
 * -----------------------------------------------------------------------------------------
 * Includes:
 * - Java source code for MainActivity, GridActivity, SMSActivity (for testing SMS Permissions
 * and for sending Toast Notifications)
 * - InventoryItemEntity model and InventoryAdapter for RecyclerView
 * - InventoryDao, UserDao, InventoryItemEntity to implement interfacing and with SQLite via ROOM
 * - UserEntity for inputting credentials into the app's database and for validating account
 * - XML Layouts: activity_main.xml, activity_grid.xml, item_inventory.xml, activity_sms.xml, dialog_edit_item.xml
 * - Resources: Strings.xml for better connecting the text based information
 * - Android Manifest: Updated to include launcher Icon to Launch application when built
 * -----------------------------------------------------------------------------------------
 * Note:
 *   This project was completed using Android Studio and followed the directions outlined in the Module Five Assignment Guidelines. Development and configuration were supported by the resources in the module, including:
 *   Android Developers – Build a Simple User Interface (developer.android.com)
 *   Android Developers – Design for Android (developer.android.com/design)
 *   zyBooks Chapter 5: Mobile Architecture & Programming – topics such as event handling, dynamic views, input validation and database usage.
 *
 * These resources helped guide the implementation of layout design, view behavior, input validation and database management for this assignment.
 */

package com.example.m2aim_mubeenahmedkhan;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Calendar;
import java.util.List;

// Adapter for displaying inventory items from Room in a RecyclerView
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private List<InventoryItemEntity> itemList;
    private InventoryDao inventoryDao;
    private boolean isDialogOpen = false; // To prevent multiple dialogs

    // Constructor
    public InventoryAdapter(List<InventoryItemEntity> itemList, InventoryDao inventoryDao) {
        this.itemList = itemList;
        this.inventoryDao = inventoryDao;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItemEntity item = itemList.get(position);
        holder.txtName.setText(item.name);
        holder.txtQuantity.setText(item.quantity);
        holder.txtDate.setText(item.date);

        // Delete item from Room DB and update the RecyclerView
        holder.btnDelete.setOnClickListener(v -> {
            inventoryDao.deleteItem(item);
            itemList.remove(position);
            notifyItemRemoved(position);
        });

        // Tap to update item
        holder.itemView.setOnClickListener(v -> {
            if (isDialogOpen) return;
            isDialogOpen = true;

            Context context = v.getContext();
            LayoutInflater inflater = LayoutInflater.from(context);
            View dialogView = inflater.inflate(R.layout.dialog_edit_item, null);

            EditText editName = dialogView.findViewById(R.id.editName);
            EditText editQuantity = dialogView.findViewById(R.id.editQuantity);
            EditText editDate = dialogView.findViewById(R.id.editDate);

            // Pre-fill existing data
            editName.setText(item.name);
            editQuantity.setText(item.quantity);
            editDate.setText(item.date);

            // Date picker logic
            editDate.setOnClickListener(v1 -> {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                        (view, selectedYear, selectedMonth, selectedDay) -> {
                            String formatted = String.format("%02d/%02d/%04d", selectedMonth + 1, selectedDay, selectedYear);
                            editDate.setText(formatted);
                        }, year, month, day);
                datePickerDialog.show();
            });

            // Build and show dialog
            new AlertDialog.Builder(context)
                    .setTitle("Update Item")
                    .setView(dialogView)
                    .setCancelable(false)
                    .setPositiveButton("Update", (dialog, which) -> {
                        item.name = editName.getText().toString().trim();
                        item.quantity = editQuantity.getText().toString().trim();
                        item.date = editDate.getText().toString().trim();

                        inventoryDao.updateItem(item);
                        notifyItemChanged(position);

                        // ✅ Check if quantity is now low
                        try {
                            int qty = Integer.parseInt(item.quantity);
                            if (qty < 5) {
                                sendLowInventoryAlert(context, item.name, qty);
                            }
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        isDialogOpen = false;
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> {
                        isDialogOpen = false;
                        dialog.dismiss();
                    })
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // Method to send low inventory SMS alert
    private void sendLowInventoryAlert(Context context, String itemName, int qty) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            SmsManager smsManager = context.getSystemService(SmsManager.class);
            String message = "ALERT: Inventory low for item: " + itemName + " (Qty: " + qty + ")";
            smsManager.sendTextMessage("+1234567890", null, message, null, null);
            Toast.makeText(context, "Low inventory SMS sent.", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(context, "SMS permission not granted.", Toast.LENGTH_SHORT).show();
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtName, txtQuantity, txtDate;
        Button btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            txtDate = itemView.findViewById(R.id.txtDate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}