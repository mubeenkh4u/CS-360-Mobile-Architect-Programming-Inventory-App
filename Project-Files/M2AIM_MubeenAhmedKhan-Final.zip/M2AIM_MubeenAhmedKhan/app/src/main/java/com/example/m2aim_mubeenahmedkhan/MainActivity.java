/*
 * -----------------------------------------------------------------------------------------
 * Course Name    :   CS 360 - Mobile Architect and Planning
 * Project Phase  :   Complete CRUD Implementation
 * App Type       :   Inventory Management
 * Professor Name :   Alex Benavente
 * Student Name   :   Mubeen Ahmed Khan (MAK)
 * Date           :   MAK  (as of completion 6/22/2025)
 * -----------------------------------------------------------------------------------------
 * Includes:
 * - Java source code for MainActivity, GridActivity, SMSActivity (for testing SMS Permissions
 * and for sending Toast Notifications)
 * - InventoryItemEntity model and InventoryAdapter for RecyclerView
 * - InventoryDao, UserDao, InventoryItemEntity to implement interfacing and with SQLite via ROOM
 * - UserEntity for inputting credentials into the app's database and for validating account
 * - XML Layouts: activity_main.xml, activity_grid.xml, item_inventory.xml, activity_sms.xml, dialog_edit_item.xml
 * - Resources: Strings.xml for better connecting the text based information
 * - Android Manifest: Updated to include launcher Icon to Launch application when built
 * -----------------------------------------------------------------------------------------
 * Note:
 *   This project was completed using Android Studio and followed the directions outlined in the Module Five Assignment Guidelines. Development and configuration were supported by the resources in the module, including:
 *   Android Developers – Build a Simple User Interface (developer.android.com)
 *   Android Developers – Design for Android (developer.android.com/design)
 *   zyBooks Chapter 5: Mobile Architecture & Programming – topics such as event handling, dynamic views, input validation and database usage.
 *
 * These resources helped guide the implementation of layout design, view behavior, input validation and database management for this assignment.
 */

package com.example.m2aim_mubeenahmedkhan;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button btnLogin, btnSignup;
    UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind UI components
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnSignup = findViewById(R.id.btnSignup);

        // Access DAO
        userDao = AppDatabase.getInstance(this).userDao();

        // Handle login logic
        btnLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString();
            String password = editPassword.getText().toString();
            UserEntity user = userDao.authenticate(username, password);

            if (user != null) {
                Intent intent = new Intent(MainActivity.this, GridActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid login.", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle account creation logic
        btnSignup.setOnClickListener(v -> {
            String username = editUsername.getText().toString();
            String password = editPassword.getText().toString();

            if (userDao.findUserByUsername(username) != null) {
                Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
            } else {
                userDao.insertUser(new UserEntity(username, password));
                Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}