/*
 * -----------------------------------------------------------------------------------------
 * Course Name    :   CS 360 - Mobile Architect and Planning
 * Project Phase  :   Complete CRUD Implementation
 * App Type       :   Inventory Management
 * Professor Name :   Alex Benavente
 * Student Name   :   Mubeen Ahmed Khan (MAK)
 * Date           :   MAK  (as of completion 6/22/2025)
 * -----------------------------------------------------------------------------------------
 * Includes:
 * - Java source code for MainActivity, GridActivity, SMSActivity (for testing SMS Permissions
 * and for sending Toast Notifications)
 * - InventoryItemEntity model and InventoryAdapter for RecyclerView
 * - InventoryDao, UserDao, InventoryItemEntity to implement interfacing and with SQLite via ROOM
 * - UserEntity for inputting credentials into the app's database and for validating account
 * - XML Layouts: activity_main.xml, activity_grid.xml, item_inventory.xml, activity_sms.xml, dialog_edit_item.xml
 * - Resources: Strings.xml for better connecting the text based information
 * - Android Manifest: Updated to include launcher Icon to Launch application when built
 * -----------------------------------------------------------------------------------------
 * Note:
 *   This project was completed using Android Studio and followed the directions outlined in the Module Five Assignment Guidelines. Development and configuration were supported by the resources in the module, including:
 *   Android Developers – Build a Simple User Interface (developer.android.com)
 *   Android Developers – Design for Android (developer.android.com/design)
 *   zyBooks Chapter 5: Mobile Architecture & Programming – topics such as event handling, dynamic views, input validation and database usage.
 *
 * These resources helped guide the implementation of layout design, view behavior, input validation and database management for this assignment.
 */

package com.example.m2aim_mubeenahmedkhan;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class GridActivity extends AppCompatActivity {

    // UI components
    RecyclerView recyclerView;
    Button btnAdd, btnCheckSMS;
    EditText editItemName, editQuantity, editDate;

    // Adapter and database access
    InventoryAdapter adapter;
    List<InventoryItemEntity> itemList;
    InventoryDao dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        // Bind buttons and RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        btnAdd = findViewById(R.id.btnAdd);
        btnCheckSMS = findViewById(R.id.btnCheckSMS);

        // Bind input fields
        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        editDate = findViewById(R.id.editDate);

        // Setup DAO and fetch data
        dao = AppDatabase.getInstance(this).inventoryDao();
        itemList = dao.getAllItems();

        // Setup adapter and display list
        adapter = new InventoryAdapter(itemList, dao);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // ✅ Check for low inventory after login
        checkInventoryForLowItems();

        // Add item button logic
        btnAdd.setOnClickListener(v -> {
            String name = editItemName.getText().toString().trim();
            String quantity = editQuantity.getText().toString().trim();
            String date = editDate.getText().toString().trim();

            if (!name.isEmpty() && !quantity.isEmpty() && !date.isEmpty()) {
                InventoryItemEntity newItem = new InventoryItemEntity(name, quantity, date);
                dao.insertItem(newItem);

                // Refresh list
                itemList.clear();
                itemList.addAll(dao.getAllItems());
                adapter.notifyDataSetChanged();

                // Clear inputs
                editItemName.setText("");
                editQuantity.setText("");
                editDate.setText("");

                // ✅ Check if new item is low
                checkLowInventoryAndNotify(name, quantity);
            } else {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            }
        });

        // Navigate to SMS permission tester
        btnCheckSMS.setOnClickListener(v -> {
            Intent intent = new Intent(GridActivity.this, SMSActivity.class);
            startActivity(intent);
        });
    }

    // Check low inventory on startup
    private void checkInventoryForLowItems() {
        for (InventoryItemEntity item : itemList) {
            try {
                int qty = Integer.parseInt(item.quantity);
                if (qty < 25) { // 25% threshold
                    sendLowInventoryAlert(item.name, qty);
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    // Check new item for alert after adding
    private void checkLowInventoryAndNotify(String itemName, String quantityStr) {
        try {
            int qty = Integer.parseInt(quantityStr);
            if (qty < 25) {
                sendLowInventoryAlert(itemName, qty);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    // Send alert SMS
    private void sendLowInventoryAlert(String itemName, int qty) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            SmsManager smsManager = getSystemService(SmsManager.class);
            String message = "ALERT: Inventory low for item: " + itemName + " (Qty: " + qty + ")";
            smsManager.sendTextMessage("+1234567890", null, message, null, null);
            Toast.makeText(this, "Low inventory SMS sent.", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(this, "SMS permission not granted. Cannot send alert.", Toast.LENGTH_SHORT).show();
        }
    }
}